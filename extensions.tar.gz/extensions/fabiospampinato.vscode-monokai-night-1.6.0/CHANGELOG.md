### Version 1.6.0
- Customized some new colors

### Version 1.5.0
- Ensuring whitespace characters are visible when selected
- Customized new colors

### Version 1.4.1
- Readme: added a “Related Themes” section

### Version 1.4.0
- Properties sorted alphabetically
- Customized some extra colors

### Version 1.3.5
- Updated stack frame-related colors

### Version 1.3.4
- Customized new colors

### Version 1.3.3
- Readme: using hi-res logo

### Version 1.3.2
- Using "Debug Launcher" for debugging

### Version 1.3.1
- Updated `activityBar.inactiveForeground`

### Version 1.3.0
- Customized new colors

### Version 1.2.0
- Customized the breadcrumb
- Customized the settings
- Customized menu and menubar

### Version 1.1.2
- Updated line/range highlight colors

### Version 1.1.1
- Updated logo

### Version 1.1.0
- Customized new colors

### Version 1.0.0
- Initial release
