# Sponsors

While GitLens is no longer accepting sponsorships, I've had some incredible sponsors over the years &mdash; thank you so much for your contributions. I am truly humbled by your generosity and support. &#x1f496;

## Corporate Sponsors

<p align="center">
  <a title="Try CodeStream &mdash; Pull Requests and Code Reviews in your IDE" href="https://sponsorlink.codestream.com/?utm_source=vscmarket&utm_medium=banner&utm_campaign=gitlens"><img src="https://alt-images.codestream.com/codestream_logo_gitlens_vscmarket.png" alt="CodeStream Logo &mdash; Pull Requests and Code Reviews in your IDE"/></a>
  <a title="Visit Embark Studios" href="https://embark-studios.com"><img src="https://raw.githubusercontent.com/eamodio/vscode-gitlens/main/images/docs/sponsors/embark-studios_dark.png" alt="Embark Studios Logo"/></a>
  <a title="Visit Localize" href="https://localizejs.com"><img src="https://raw.githubusercontent.com/eamodio/vscode-gitlens/main/images/docs/sponsors/localize_dark.png" alt="Localize Logo"/></a>
  <a title="Try Tabnine Autocomplete" href="http://wd5a.2.vu/GitLens"><img src="https://raw.githubusercontent.com/eamodio/vscode-gitlens/main/images/docs/sponsors/tabnine.png" alt="Tabnine Logo"/></a>
  <a title="Try Dendron — the IDE for General Knowledge" href="https://www.dendron.so"><img src="https://raw.githubusercontent.com/eamodio/vscode-gitlens/main/images/docs/sponsors/dendron.png" alt="Dendron Logo"/></a>
  <a title="Try Stepsize" href="https://bit.ly/3A5zaNg"><img src="https://raw.githubusercontent.com/eamodio/vscode-gitlens/main/images/docs/sponsors/stepsize.png" alt="Stepsize Logo"/></a>
  <a title="Visit Crésus" href="https://cresus.ch"><img src="https://raw.githubusercontent.com/eamodio/vscode-gitlens/main/images/docs/sponsors/cresus.png" alt="Crésus Logo"/></a>
</p>

## User Sponsors

- Borek Bernard
- Jack
- Ken Howard
- Michael Duffy
- Michael Scott-Nelson
- MrG0lden
- Sergey Cheperis
- Xananax
- Andreas Fertsch-Röver
- Bill
- Brandon Burroughs
- Brent Schmidt
- Diego La Manno
- Eugen Grue
- Georg Hartmann
- Guido Kessels
- J Burnett
- JehongAhn
- Jon G
- Jordan Oroshiba
- Karl
- Michael Melanson
- Niklas Lochschmidt
- Pavel Khlopin
- Pelle Wessman
- Raphael Schweikert
- sombriks
- Stephen Kelley
- Steven Hepting
- Sunny Gupta
- Vance Dubberly
- Øyvind de Freitas Sørensen
- Kori Roys
- Michael Lang
- Ian Maclean
- Sergey Cheperis
- Asem Hasna
- gb
- John Sweeney
- ember arlynx
- Bharat Arimilli
- Darrin Massena
- M365Bass
- Sandeep kumar
- Lawrence H. Leach
