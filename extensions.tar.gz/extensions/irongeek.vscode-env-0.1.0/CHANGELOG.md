# Changelog

## [0.1.0] ｜ 2020-10-13

### Features

↳ [`53e6022`](https://github.com/IronGeek/vscode-env/commit/53e6022cb0fbea99d3e6a678cd610904c18f548d) initial commit

[0.1.0]: https://github.com/IronGeek/vscode-env/releases/tag/v0.1.0 "v0.1.0"
