<!-- Empty file to allow rendering a walkthrough step "without" media -->
